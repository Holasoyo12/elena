from django.db import models

class Alumnos(models.Model): # Define la estructura de nuestra tabla
    matricula = models.CharField(max_length=12) #Texto corto    
    nombre = models.TextField()  #Texto largo 
    carrera = models.TextField()
    turno= models.CharField(max_length=10)
    imagen = models.ImageField(upload_to='fotos', null=True, verbose_name="Fotografía") #Campo para subir imagenes
    created = models.DateTimeField(auto_now_add=True) #Fecha y tiempo
    updated = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Alumno"
        verbose_name_plural = "Alumnos"
        ordering = ["-created"]
        #el menos indica que se ordenada de mas reciente al mas viejo
    
    def __str__(self):
        return self.nombre

# Create your models here.  
